import streamlit as st

# Set page title
st.set_page_config(page_title="AI Event Management", page_icon="📅", layout="wide")

st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Home", "User Dashboard", "Host Dashboard", "AI Insights", "Predictive Analytics"])

# Navigation logic
if page == "Home":
    st.title("Welcome to AI Event Management & Engagement System")
    st.write("An AI-powered event platform for smart recommendations and insights.")

elif page == "User Dashboard":
    st.switch_page("pages/user_dashboard.py")

elif page == "Host Dashboard":
    st.switch_page("pages/host_dashboard.py")

elif page == "AI Insights":
    st.switch_page("pages/ai_insights.py")

elif page == "Predictive Analytics":
    st.switch_page("pages/predictive_analytics.py")
