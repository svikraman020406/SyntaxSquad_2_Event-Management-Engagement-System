const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const Event = require("../models/Event");

const router = express.Router();

// Create Event
router.post("/", protect, async (req, res) => {
  try {
    const event = await Event.create({ ...req.body, createdBy: req.user.id });
    res.status(201).json(event);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get All Events
router.get("/", async (req, res) => {
  const events = await Event.findAll({ include: { all: true } });
  res.json(events);
});

module.exports = router;
