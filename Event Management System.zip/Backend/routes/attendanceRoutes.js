const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const Attendance = require("../models/Attendance");

const router = express.Router();

// Register for an Event
router.post("/:eventId/register", protect, async (req, res) => {
  try {
    await Attendance.create({ userId: req.user.id, eventId: req.params.eventId });
    res.json({ message: "Attendance recorded successfully" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
