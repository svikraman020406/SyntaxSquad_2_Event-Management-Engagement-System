const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db");
const User = require("./User");
const Event = require("./Event");

const Attendance = sequelize.define("Attendance", {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
});

Attendance.belongsTo(User, { foreignKey: "userId" });
Attendance.belongsTo(Event, { foreignKey: "eventId" });

module.exports = Attendance;
