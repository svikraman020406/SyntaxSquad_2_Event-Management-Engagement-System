require("dotenv").config();
const express = require("express");
const { connectDB, sequelize } = require("./config/db");

const app = express();
app.use(express.json());

connectDB();

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/events", require("./routes/eventRoutes"));
app.use("/api/attendance", require("./routes/attendanceRoutes"));

// Sync Database
sequelize.sync({ alter: true }).then(() => console.log("Database Synced!"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
