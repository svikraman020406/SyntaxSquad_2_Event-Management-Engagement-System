import streamlit as st

st.set_page_config(page_title="Host Dashboard", page_icon="🎤")

st.title("Host Dashboard")
st.write("Create and manage your events.")

event_name = st.text_input("Event Name")
event_date = st.date_input("Event Date")
submit_button = st.button("Create Event")

if submit_button:
    st.success(f"Event '{event_name}' created for {event_date}!")
