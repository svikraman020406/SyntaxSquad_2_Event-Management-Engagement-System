import streamlit as st

st.set_page_config(page_title="User Dashboard", page_icon="👤")

st.title("User Dashboard")
st.write("View and manage your event bookings.")

# Example User Data
st.subheader("My Bookings")
st.table({"Event": ["Tech Summit", "AI Workshop"], "Date": ["2025-03-10", "2025-04-05"]})

st.subheader("Recommended Events")
st.write("🎯 AI-generated event recommendations coming soon!")
